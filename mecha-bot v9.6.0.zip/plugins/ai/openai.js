exports.run = {
usage: ['openai'],
hidden: ['ai'],
use: 'text',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'apa itu coding'))
let wait = await mecha.sendMessage(m.chat, {text: global.mess.wait}, {quoted: m, ephemeralExpiration: m.expiration})
try {
let res = await func.fetchJson(`https://aemt.me/openai?text=${m.text}`)
if (!res.status) return await mecha.sendMessage(m.chat, {text: global.mess.error.api, edit: wait.key }, {quoted: m, ephemeralExpiration: m.expiration});
await mecha.sendMessage(m.chat, {text: `${res.result}`, edit: wait.key }, {quoted: m, ephemeralExpiration: m.expiration});
} catch (e) {
m.reply('Maaf terjadi kesalahan!');
}
},
limit: 3
}